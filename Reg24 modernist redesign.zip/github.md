repo: classichot/REG24
branch: main

## Last sync
date: 2026-10-22T01:51:24Z

### Updated in this project
- All 8 top-nav destinations rebuilt in the minimal cobalt concept
- Content lifted from page.tsx sections, SCREEN_CONFIG and the universal MCP gateway
- Two-row header so Developer / Control / 16 Modules never truncate

## Screen map
| Screen | Repo files |
| --- | --- |
| v2 · Research | src/app/page.tsx (uxResearchDestination "research"), screenshot |
| v2 · Workspace | src/app/page.tsx (uxResearchDestination "workspace") |
| v2 · Databases | src/app/page.tsx (uxResearchDestination "library") |
| v2 · NotebookLM | src/app/page.tsx (uxResearchDestination "notebooklm") |
| v2 · Connect AI (MCP) | src/app/page.tsx (uxResearchDestination "connect_ai"), src/core/mcp/universal-mcp-gateway.ts |
| v2 · Developer | src/app/page.tsx (uxExperience "infrastructure") |
| v2 · Control | src/app/page.tsx (uxExperience "control") |
| v2 · 16 Modules | src/app/page.tsx (SCREEN_CONFIG) |
| v2 · Database dialog | README.md (P0 modules) |
| REG24 Redesign.dc.html — first exploration | src/app/layout.tsx (metadata) |
